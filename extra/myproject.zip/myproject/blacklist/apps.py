from django.apps import AppConfig


class BlacklistConfig(AppConfig):
    name = 'blacklist'
