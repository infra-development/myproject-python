from django.contrib import admin
from .models import Newsletter

# Register your models here.

admin.site.register(Newsletter)
